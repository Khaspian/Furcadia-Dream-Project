Playground
Credits/Terms of Service:
 
- Created by Pai.

- By using this patch you agree that you will not redistribute it to anyone, but may edit them to your hearts content. But, remember to give Pai credit, even for editted work.

(I'd be interested in seeing any edits, so feel free to send me a screenshot at altshed@gmail.com)

- You agree to give credit to Pai somewhere within the dream (Opening emits, or commands, etc).

Thank you for abiding by the terms, if you have any questions feel free to leave me a message online or at my e-mail listed above.