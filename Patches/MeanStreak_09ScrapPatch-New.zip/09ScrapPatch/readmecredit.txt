Please note:
The lounge couch item has a pillow made by Mint Mink.
The slanted walls form to make pyramid shapes and can be used with DEP's Festival of the Sun patches.
New floor tilea to fit into the desert scene as well as carpets.
The pew couch was made for Peddler's Byht.

-----------*-------------
A note from Kaelin'yFiae in which I echo.

It is good practice to always include credit when using material composed by another person, such as art or literature. You can do that by adding a .txt file to your personal map files. It's easy to do, and adds almost nothing to your map's download time! You gain by earning the respect of those around you. Please credit other creative individuals when using their material. 
----------------
Always FREE Never for Sale!!
09ScrapItems MeanStreak�Publishing-MSDigitalDesign 2009