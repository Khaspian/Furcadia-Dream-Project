This is the default 'floors.fox' file with all of the default water overwritten with the new animated water. The accompanying iteme.fox file includes a raised water tile for lakes and such for furres to 'swim' in, as well as 2 animated 'splash' tiles for docks, etc.
Floor tiles 137-139 are shadowed for use against a building or under docks.


Full patch created by Lady Enchantres (Heather B. Duthie)

Free for use and free to edit.
Not for resale.  Not to be used in a dream being sold.